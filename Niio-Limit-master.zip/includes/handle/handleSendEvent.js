module.exports = function ({ api, models, Users, Threads, Currencies }) {
    return async function (event) {
        // console.log(event)
        // update sau
    }
}